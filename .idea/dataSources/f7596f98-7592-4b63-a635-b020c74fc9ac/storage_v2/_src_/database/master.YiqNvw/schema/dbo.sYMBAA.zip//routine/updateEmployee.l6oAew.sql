-- Update Employe
CREATE PROCEDURE updateEmployee(
	@employee_ID INT,
	@employee_Name NVARCHAR(255),
	@employee_landLine VARCHAR(11),
	@employee_mobilePhone VARCHAR(11),
	@email VARCHAR(255)
)
AS
BEGIN
	BEGIN TRY
		UPDATE tblEmployee
		SET EmployeeName = EmployeeName,
		Landline = @employee_landLine,
		MobilePhone = @employee_mobilePhone,
		Email = @email
		WHERE EmployeeID = @employee_ID
	END TRY
	BEGIN CATCH
		INSERT INTO tblErrorLog(ErrorNumber, ErrorMessage)
		VALUES (ERROR_NUMBER(), ERROR_MESSAGE());
		SELECT
		ERROR_NUMBER() AS ErrorNumber,
		ERROR_MESSAGE() AS ErrorMessage
	END CATCH
END;
go

